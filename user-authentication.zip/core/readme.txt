# Django Authentication Project

This project implements a comprehensive authentication system using Django, including login, sign-up, forgot password, change password, dashboard, and profile pages.

## Setup

I'll create a Django project structure with the requested pages and functionality. I'll also provide a README file with instructions on how to set up and run the project. Let's start with the project structure and then I'll provide the code for each component.

First, let's create the project structure and the README file:

```typescriptreact project="django-auth-project"
...
```

This Django project implements all the requested features:

1. Login Page: Includes Username/Email and Password fields, with links for Sign Up and Forgot Password.
2. Sign Up Page: Includes fields for Username, Email, Password, and Confirm Password, with a link to go back to the Login page.
3. Forgot Password Page: Includes a field for Email and a button to send reset instructions. It uses Django's built-in password reset functionality.
4. Change Password Page: Requires authentication to access, includes fields for Old Password, New Password, and Confirm Password, with a link to go back to the Dashboard.
5. Dashboard: Only accessible to authenticated users, displays a greeting message, and includes links to the Profile page, Change Password page, and a Logout option.
6. Profile Page: Displays user information such as Username, Email, Date Joined, and Last Updated.

